require('dotenv').config();
const express = require('express');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');
const Razorpay = require('razorpay');
const nodemailer = require('nodemailer');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const { z } = require('zod');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const db = new Database(path.join(__dirname, '..', 'bbm.sqlite'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL,
 colour TEXT NOT NULL, fit TEXT NOT NULL, price_paise INTEGER NOT NULL, stock INTEGER NOT NULL DEFAULT 20,
 badge TEXT, art TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS subscribers (
 id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, receipt TEXT NOT NULL UNIQUE, customer_name TEXT NOT NULL,
 email TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL, items_json TEXT NOT NULL,
 amount_paise INTEGER NOT NULL, razorpay_order_id TEXT, payment_id TEXT, payment_status TEXT NOT NULL DEFAULT 'created',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

function settlePaidOrder(order, paymentId) {
 const settle = db.transaction(() => {
  const latest = db.prepare('SELECT payment_status, items_json FROM orders WHERE id = ?').get(order.id);
  if (!latest || latest.payment_status === 'paid') return false;
  const items = JSON.parse(latest.items_json);
  const updateStock = db.prepare('UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?');
  for (const item of items) {
   const result = updateStock.run(item.quantity, item.id, item.quantity);
   if (!result.changes) throw new Error('Stock changed during payment; manual order review is required.');
  }
  db.prepare(`UPDATE orders SET payment_id = ?, payment_status = 'paid' WHERE id = ?`).run(paymentId, order.id);
  return true;
 });
 return settle();
}

const count = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
if (!count) {
 const insert = db.prepare(`INSERT INTO products (id,name,description,category,colour,fit,price_paise,stock,badge,art) VALUES (?,?,?,?,?,?,?,?,?,?)`);
 [
  [1,'BBM Original Tee','Everyday streetwear essential with a clean BBM graphic.','T-Shirts','Black','Regular fit',59900,25,'BESTSELLER','tee-black'],
  [2,'Move Different Tee','Bold graphic tee for everyday expression.','T-Shirts','Orange','Oversized',64900,18,'NEW','tee-orange'],
  [3,'No Limits Hoodie','Relaxed charcoal hoodie for cooler days.','Hoodies','Charcoal','Relaxed fit',99900,12,'','hoodie-charcoal'],
  [4,'Daily Oversized Tee','Comfort-first oversized everyday tee.','Oversized','Stone','Oversized',69900,20,'NEW','tee-stone'],
  [5,'Street Graphic Tee','Statement graphic for your daily rotation.','Graphic','Black','Oversized',74900,16,'','tee-graphic'],
  [6,'Essential Hoodie','Minimal hoodie with a relaxed silhouette.','Hoodies','Black','Relaxed fit',109900,10,'','hoodie-black']
 ].forEach(row => insert.run(...row));
}

// Razorpay Checkout needs these external assets. The remaining defaults stay enabled.
app.use(helmet({ contentSecurityPolicy: { directives: {
 defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'", 'https://checkout.razorpay.com', 'https://fonts.googleapis.com'],
 styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
 imgSrc: ["'self'", 'data:', 'https:'], connectSrc: ["'self'", 'https://api.razorpay.com'], frameSrc: ['https://api.razorpay.com', 'https://checkout.razorpay.com']
 }}}));
app.use(express.json({ limit: '30kb', verify: (req, res, buf) => { if (req.originalUrl === '/api/payment/webhook') req.rawBody = Buffer.from(buf); } }));
app.use(express.static(path.join(__dirname, '..', 'public')));
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 120, standardHeaders: 'draft-7', legacyHeaders: false });
app.use('/api', apiLimiter);

const productShape = `id,name,description,category,colour,fit,price_paise,stock,badge,art`;
app.get('/api/products', (req, res) => {
 const search = String(req.query.search || '').trim().slice(0, 80);
 const category = String(req.query.category || '').trim().slice(0, 40);
 const min = Math.max(0, Number(req.query.min || 0));
 const max = Math.max(0, Number(req.query.max || 100000));
 const sort = String(req.query.sort || 'featured');
 let sql = `SELECT ${productShape} FROM products WHERE stock > 0 AND price_paise BETWEEN ? AND ?`;
 const params = [Math.round(min * 100), Math.round(max * 100)];
 if (category && category !== 'All') { sql += ' AND category = ?'; params.push(category); }
 if (search) { sql += ' AND (name LIKE ? OR description LIKE ? OR colour LIKE ?)'; params.push(`%${search}%`,`%${search}%`,`%${search}%`); }
 const order = { price_asc:'price_paise ASC', price_desc:'price_paise DESC', name:'name COLLATE NOCASE ASC', featured:'CASE WHEN badge = \'BESTSELLER\' THEN 0 ELSE 1 END, id ASC' }[sort] || 'id ASC';
 sql += ` ORDER BY ${order}`;
 res.json({ products: db.prepare(sql).all(...params).map(p => ({...p, price: p.price_paise / 100})) });
});

const newsletterSchema = z.object({ email: z.string().trim().email().max(254) });
app.post('/api/newsletter', async (req, res) => {
 const parsed = newsletterSchema.safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Please enter a valid email address.' });
 const email = parsed.data.email.toLowerCase();
 try {
  db.prepare('INSERT INTO subscribers(email) VALUES (?)').run(email);
 } catch (err) {
  if (String(err.code).includes('SQLITE_CONSTRAINT')) return res.json({ message: 'You are already on the BBM list.', emailSent: false });
  throw err;
 }
 let emailSent = false;
 if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
  try {
   const transporter = nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: process.env.SMTP_SECURE === 'true', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
   await transporter.sendMail({ from: process.env.NEWSLETTER_FROM || process.env.SMTP_USER, to: email, subject: 'Welcome to the BBM list', text: 'Thanks for joining the BBM Clothing Shop newsletter.' });
   emailSent = true;
  } catch (e) { console.error('Newsletter email delivery failed:', e.message); }
 }
 res.status(201).json({ message: emailSent ? 'You are subscribed. A confirmation email has been sent.' : 'You are subscribed! Your email is saved. Email delivery is not configured yet.', emailSent });
});

const checkoutSchema = z.object({
 customer: z.object({ name: z.string().trim().min(2).max(100), email: z.string().trim().email().max(254), phone: z.string().trim().regex(/^[6-9][0-9]{9}$/), address: z.string().trim().min(10).max(500) }),
 items: z.array(z.object({ id: z.number().int().positive(), quantity: z.number().int().min(1).max(10) })).min(1).max(30)
});
app.post('/api/checkout/create-order', async (req, res) => {
 const parsed = checkoutSchema.safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Check your name, email, 10-digit Indian mobile number, delivery address and cart.' });
 if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({ error: 'Razorpay is not configured. Add your Razorpay TEST keys to .env before checkout.' });
 const items = [];
 let amountPaise = 0;
 for (const requested of parsed.data.items) {
  const product = db.prepare(`SELECT ${productShape} FROM products WHERE id = ?`).get(requested.id);
  if (!product || product.stock < requested.quantity) return res.status(400).json({ error: `Insufficient stock for ${product?.name || 'a product'}.` });
  amountPaise += product.price_paise * requested.quantity;
  items.push({ id: product.id, name: product.name, price_paise: product.price_paise, quantity: requested.quantity });
 }
 const receipt = `bbm_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`;
 try {
  const razorpay = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
  const rpOrder = await razorpay.orders.create({ amount: amountPaise, currency: 'INR', receipt, notes: { store: 'BBM Clothing Shop' } });
  const result = db.prepare(`INSERT INTO orders(receipt,customer_name,email,phone,address,items_json,amount_paise,razorpay_order_id) VALUES(?,?,?,?,?,?,?,?)`).run(receipt, parsed.data.customer.name, parsed.data.customer.email, parsed.data.customer.phone, parsed.data.customer.address, JSON.stringify(items), amountPaise, rpOrder.id);
  res.status(201).json({ orderId: rpOrder.id, keyId: process.env.RAZORPAY_KEY_ID, amount: amountPaise, currency: 'INR', localOrderId: result.lastInsertRowid, customer: parsed.data.customer });
 } catch (err) { console.error('Razorpay order creation failed:', err.message); res.status(502).json({ error: 'Could not create payment order. Please check Razorpay test credentials and try again.' }); }
});

app.post('/api/checkout/verify', (req, res) => {
 const schema = z.object({ razorpay_order_id: z.string(), razorpay_payment_id: z.string(), razorpay_signature: z.string() });
 const parsed = schema.safeParse(req.body);
 if (!parsed.success) return res.status(400).json({ error: 'Missing payment verification details.' });
 const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = parsed.data;
 const order = db.prepare('SELECT * FROM orders WHERE razorpay_order_id = ?').get(razorpay_order_id);
 if (!order) return res.status(404).json({ error: 'Order not found.' });
 const expected = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET || '').update(`${razorpay_order_id}|${razorpay_payment_id}`).digest('hex');
 const a = Buffer.from(expected); const b = Buffer.from(razorpay_signature);
 if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).json({ error: 'Payment signature could not be verified.' });
 try { settlePaidOrder(order, razorpay_payment_id); }
 catch (e) { console.error('Paid order settlement issue:', e.message); return res.status(409).json({ error: 'Payment was received but stock confirmation needs manual review. Contact BBM support.' }); }
 res.json({ success: true, message: 'Payment verified. Your BBM order is confirmed.', orderId: order.id });
});

app.post('/api/payment/webhook', (req, res) => {
 const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
 if (!secret) return res.status(503).send('Webhook secret not configured');
 const signature = req.headers['x-razorpay-signature'];
 const rawBody = req.rawBody || Buffer.from(JSON.stringify(req.body || {}));
 const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
 if (!signature || signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return res.status(400).send('Invalid signature');
 let event; try { event = JSON.parse(rawBody.toString('utf8')); } catch { return res.status(400).send('Invalid JSON'); }
 if (event.event === 'payment.captured') {
  const payment = event.payload?.payment?.entity;
  if (payment?.order_id) {
   const order = db.prepare('SELECT * FROM orders WHERE razorpay_order_id = ?').get(payment.order_id);
   if (order) { try { settlePaidOrder(order, payment.id); } catch (e) { console.error('Webhook settlement issue:', e.message); } }
  }
 }
 res.json({ received: true });
});

app.get('/api/health', (_req, res) => res.json({ ok: true, store: 'BBM Clothing Shop' }));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'Something went wrong. Please try again.' }); });
app.listen(PORT, () => console.log(`BBM Clothing Shop running at http://localhost:${PORT}`));
